<?php
###############################################################################
###############################################################################
##                                                                           ##
##                                                                           ##
##  PROGRAMMED BY IRAN-PHP.COM TEAMS,                                        ##
##  HTTP://WWW.IRAN-PHP.COM                                                  ##
##  Copyright (c) 2005-2008 IranPHP                                          ##
##  MODIFIED AT 2008.12.21                                                   ##
##  MC.INSTALLER VERSION 4.6                                                 ##
##                                                                           ##
##                                                                           ##
###############################################################################
###############################################################################

##___________________________________________________________________________________________________
function zarinpal_createPaymentFormAndSubmit(){
	$mysqlInsertId = BRING_NEW_SaleCode();
	if(!$form['pay_value'] = $_REQUEST['EPAYAMOUNT']){
		echo cadr('errr137');
		return false;
	} else if(!mysql_query(" UPDATE `epay` SET `pay_value`='".$form['pay_value']."' WHERE `method`='zarinpal' AND `id`='$mysqlInsertId' LIMIT 1 ")){
		echo cadr('errr137');
		return false;
	} else if($_REQUEST['EPAYMETHOD']!='zarinpal'){
		echo cadr('errr141');
		return false;
	} else if(!$res_banks=mysql_query(" select * from `epay_plans` where `method`='zarinpal' limit 1 ")){
		echo cadr('errr144');
		return false;
	} else if(mysql_num_rows($res_banks)!=1){
		echo cadr('errr147');
		return false;
	} // else ...
	$rec_banks = mysql_fetch_array($res_banks);
	$rials = $form['pay_value']/$rec_banks['unit_cost'];
	$RedirectURL = _URL."/process.php?do=returnFromBank&mysqlInsertId=$mysqlInsertId";
	include_once('./nusoap.php');
	$client = new nusoap_client('http://www.zarinpal.com/WebserviceGateway/wsdl', 'wsdl');
	$res = $client->call('PaymentRequest', array($rec_banks['fld2'], $rials, $RedirectURL, $mysqlInsertId));
	//Redirect to URL You can do it also by creating a form
	echo "<script>location.href='https://www.zarinpal.com/users/pay_invoice/".$res."';</script>";
	return true;
}

##___________________________________________________________________________________________________
function zarinpal_returnFromBank(){
	require_once('./nusoap.php');
	$batch = $_REQUEST['au'];
	$id = $_REQUEST['mysqlInsertId'];
	
	if(!$res_payments = mysql_query(" select * from `epay` where 1 and `id`='$id' limit 1 ")){
		echo cadr('e67');
		die();
	} else if(mysql_num_rows($res_payments)!=1){
		echo cadr('Payment record not found e71');
		die();
	} // else ...
	$rec_payments = mysql_fetch_array($res_payments);
	
	if(intval($rec_payments['pay_value'])<=0){
		echo cadr('Invalid value e76');
		die();
	}
	
	if(!$res_banks = mysql_query(" select * from `epay_plans` where 1 and `method`='zarinpal' limit 1 ")){
		echo cadr('e87');
		die();
	} else if(mysql_num_rows($res_banks)!=1){
		echo cadr('Bank method not found e91');
		die();
	} // else ...
	
	$rec_banks = mysql_fetch_array($res_banks);
	$RIALS_IN_DB = $rec_payments['pay_value'] / $rec_banks['unit_cost'];
	
	/********************************************** d o u b l e   r e q u e s t ***********************************************/
	if(!$sqlbn=mysql_query(" select * from `epay` where `batch_number`='$batch' and `method`='zarinpal' limit 1 ")){
		echo cadr('err 124');
		die();
	} else if(mysql_num_rows($sqlbn)!=0){
		echo "
		<br><br><br><br><br><br><br>
		<center>
		<table width=400 height=40 cellpadding=2 cellspacing=1 bgcolor='#936b1a'><tr><td bgcolor='#ffe8db' style='font-family:tahoma; font-size:12px; color:#8b643b; ' align=center >
		<br>
		رسيد ديجيتالي مورد نظر قبلاً در پايگاه داده ثبت شده (double request)<br>
		<br>
		<a href='"._URL."/?page=".$form['page']."'>بازگشت به محيط کاربري</a>
		<br><br>
		</td></tr></table>
		</center>";
		die();
	} // else ...
	/********************************************** d o u b l e   r e q u e s t ***********************************************/
	
	/***********************************************  v e r i f i c a t i o n  ***********************************************/	
	$merchantID = $rec_banks['fld2'];
	$client = new nusoap_client('http://www.zarinpal.com/WebserviceGateway/wsdl', 'wsdl');
	$res = $client->call("PaymentVerification", array($merchantID, $batch, $RIALS_IN_DB));
	/***********************************************  v e r i f i c a t i o n  ***********************************************/	
	
	if($res!=1){
		echo "
		<br><br><br><br><center>
		<table width=400 height=40 cellpadding=2 cellspacing=1 bgcolor='#936b1a'><tr><td bgcolor='#ffe8db' style='font-family:tahoma; font-size:12px; color:#8b643b; ' align=center >
		<b>خطاء : $res</b>
		<a href='".str_replace("/epay/zarinpal","",_URL)."'>بازگشت به محيط کاربري</a>
		</td></tr></table>
		</center><br><br>";
		die();
	}
	
	/*********************************************** s e t   i n   d a t a b a s e ***********************************************/	
	if(!$sqlset=mysql_query(" update `epay` set 
		 `batch_number`='$batch'
		,`pay_date`='".U()."'
		,`active`=1
	where 1 and `id`='$id' AND `method`='zarinpal' limit 1 ")){
		echo cadr('err 194');
		die();
	}
	/*********************************************** s e t   i n   d a t a b a s e ***********************************************/	
	
	/*********************************************** c o n g r a t u l a t i o n ***********************************************/	
	echo "
	<center>
	<table width='100%' height='100%' ><tr><td align=center >
	<table width=400 dir=rtl height=80 cellpadding=2 cellspacing=1 bgcolor='#7c931a'><tr><td bgcolor='#f6fff0' style='font-family:tahoma; font-size:12px; color:#738b3b; ' align=center >
	پاسخ بانک : <b>تأييد شد</b>
	<br>
	شماره پيگيري : <b>$batch</b>
	<br>
	<a href='".str_replace("/epay/zarinpal","",_URL)."'>بازگشت به محيط کاربري</a>
	</td></tr></table>
	</td></tr></table>
	</center>";
	die();
	/*********************************************** c o n g r a t u l a t i o n ***********************************************/		
}

##___________________________________________________________________________________________________
function CHECK_STATE_ERROR($state){
	return $state;
}

?>
