<?php

###############################################################################
###############################################################################
##                                                                           ##
##                                                                           ##
##  PROGRAMMED BY IRAN-PHP.COM TEAMS,                                        ##
##  HTTP://WWW.IRAN-PHP.COM                                                  ##
##  Copyright (c) 2005-2008 IranPHP                                          ##
##  MODIFIED AT 2008.12.21                                                   ##
##  MC.INSTALLER VERSION 4.6                                                 ##
##                                                                           ##
##                                                                           ##
###############################################################################
###############################################################################



session_start();
@ set_time_limit(180);
require_once('private.php');
chdir('../..');
include('f___.php');
chdir('epay/zarinpal');
HTML_HEADER();
db_connect();

switch($_REQUEST['do']){
	case 'returnFromBank' : 
		zarinpal_returnFromBank();
		settle_done($_REQUEST['mysqlInsertId']);
		break;
	DEFAULT : 
		zarinpal_createPaymentFormAndSubmit();
		break;
}

HTML_FOOTER();


?>
