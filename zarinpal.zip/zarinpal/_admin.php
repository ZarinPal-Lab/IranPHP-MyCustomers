<?php
###############################################################################
###############################################################################
##                                                                           ##
##                                                                           ##
##  PROGRAMMED BY IRAN-PHP.COM TEAMS,                                        ##
##  HTTP://WWW.IRAN-PHP.COM                                                  ##
##  Copyright (c) 2005-2008 IranPHP                                          ##
##  MODIFIED AT 2008.12.21                                                   ##
##  MC.INSTALLER VERSION 4.6                                                 ##
##                                                                           ##
##                                                                           ##
###############################################################################
###############################################################################

//mcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmc__________PRIVATE___INSTALLATION
function PRIVATE___INSTALLATION(){
	
	if(!$db=db_connect()){
		echo "<center class=ER1 >EpMePr:".__LINE__."</center>";
		return false;
	} else if(!$sql=mysql_query(" INSERT INTO `epay_plans`
		(`method`,`title`,`unit_cost`,`extension`,`fld1`,`fld2`) 
		VALUES ('zarinpal','ZarinPal ePay','1','nothing','YourName','Terminal PIN') ; "))
	{
		echo "<center class=ER1 >EpMePr:".__LINE__."</center>";
		return false;
	} else {
		return true;
	}
}

//mcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmc__________PRIVATE___EDIT_FORM
function PRIVATE___EDITMETHOD_FORM($mtd){
	
	if(!$epay_plans=tab__epay_plans($mtd))return false;
	
	?>
	<table bgcolor="white" width="100%" >
	<tr height="20"><td colspan="3"></td></tr>
	<tr><td width="50" ></td>
	
	
	<form method="post" action="admin.php" >
	<input type="hidden" name="ACT" value="<?=GTPT('ACT') ?>" >
	<input type="hidden" name="CPID" value="<?=GTPT('CPID') ?>" >
	<input type="hidden" name="JOB" value="<?=GTPT('JOB') ?>" >
	<input type="hidden" name="JOB2" value="EDITMETHOD_SAVE" >
	<input type="hidden" name="method" value="<?=$mtd ?>" >
	
	<td>
	<table class="EPAY_EGOLD" bgcolor="#e3ceca" width="100%" cellpadding="1" cellspacing="1" >
		<tr><th colspan="2">ZarinPal → Details</th></tr>
		<tr bgcolor="white" height="20"><td colspan="2"></td></tr>
		<tr bgcolor="white"><td><?=NBSP(10) ?>Title: </td><td><input class="EPAY_EGOLD_INPUT" type="text" name="title" value="<?=$epay_plans['title'] ?>" ></td></tr>
		<tr bgcolor="white"><td><?=NBSP(10) ?>Unit cost: </td><td><input class="EPAY_EGOLD_INPUT" type="text" name="unit_cost" value="<?=$epay_plans['unit_cost'] ?>" ></td></tr>
		<tr bgcolor="white"><td><?=NBSP(10) ?>Terminal PIN: </td><td><input class="EPAY_EGOLD_INPUT" type="text" name="fld2" value="<?=$epay_plans['fld2'] ?>" ></td></tr>
		<tr bgcolor="white"><td><?=NBSP(10) ?>Payee name: </td><td><input class="EPAY_EGOLD_INPUT" type="text" name="fld1" value="<?=$epay_plans['fld1'] ?>" ></td></tr>
		<tr bgcolor="white"><td><?=NBSP(10) ?>Extension: </td><td><textarea class="EPAY_EGOLD_INPUT" name="extension" style="height:70px; width:150"><?=$epay_plans['extension'] ?></textarea></td></tr>
		<tr bgcolor="white"><td align="center" colspan="2"><br><input type="submit" value="Save details" style="width:120px; " ><br><br></td></tr>
	</table>
	</td>
		
	</form>
		
	<td width="50" ></td></tr>
	<tr height="20"><td colspan="3"></td></tr>
	</table>
	
		
	<?	
	
	return true;
}

//mcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmcmc__________PRIVATE___SAVE_EDITMETHOD
function PRIVATE___EDITMETHOD_SAVE(){

	if(!$method=$_POST['method']){
		echo "EpMePr".__LINE__;
		return false;
	} else if(!$epay_plans=tab__epay_plans($method)){
		echo "EpMePr".__LINE__;
		return false;
	} else if(!$db=db_connect()){
		echo "EpMePr".__LINE__;
		return false;
	} else if(!$sql=mysql_query(" UPDATE epay_plans SET 
		 title='".$_POST['title']."'
		,unit_cost='".$_POST['unit_cost']."'
		,extension='".$_POST['extension']."'
		,fld1='".$_POST['fld1']."'
		,fld2='".$_POST['fld2']."'
	WHERE 1 AND method='$method' LIMIT 1  ")){
		echo "EpMePr".__LINE__;
		return false;
	} else {
		return true;
	}
}

?>
