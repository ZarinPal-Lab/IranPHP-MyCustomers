<?php
###############################################################################
###############################################################################
##                                                                           ##
##                                                                           ##
##  PROGRAMMED BY IRAN-PHP.COM TEAMS,                                        ##
##  HTTP://WWW.IRAN-PHP.COM                                                  ##
##  Copyright (c) 2005-2008 IranPHP                                          ##
##  MODIFIED AT 2008.12.21                                                   ##
##  MC.INSTALLER VERSION 4.6                                                 ##
##                                                                           ##
##                                                                           ##
###############################################################################
###############################################################################

//userMCuserMCuserMCuserMCuserMCuserMCuserMCuserMCuserMCuserMCuserMCuserMCuserMC___________________PRIVATE___PEY_FORM

function PRIVATE___PEY_FORM(){
	if(!$EPAYMETHOD=GTPT('EPAYMETHOD')){LOGOUT_USER_ERROR();return false;}
	if(!$EPAYAMOUNT=GTPT('EPAYAMOUNT')){LOGOUT_USER_ERROR();return false;}
	if(!$epay_plans=tab__epay_plans($EPAYMETHOD)){LOGOUT_USER_ERROR();return false;}
	if(!$USER=$_SESSION['USER']){LOGOUT_USER_ERROR();return false;}
	
	/*******************************************************************/
	//if(GTPT('nopayment')||GTPT('payment'))return WRITE_PAYMENT_RESULT();
	/*******************************************************************/
	
	$RedirectURL=_URL."/epay/$EPAYMETHOD/process.php";
	
	$RIALS = $EPAYAMOUNT / $epay_plans["unit_cost"];
	if($RIALS<=0){LOGOUT_USER_ERROR();return false;}
	
	if($_POST['CONTINUE']!=1){
		echo '
		<form method="post" action="'._URL.'/epay/'.$EPAYMETHOD.'/process.php" >
		<input type="hidden" name="DPT" value="'.GTPT("DPT").'" >
		<input type="hidden" name="EPAYMETHOD" value="'.GTPT("EPAYMETHOD").'" >
		<input type="hidden" name="EPAYAMOUNT" value="'.$RIALS.'" >
		<input type="hidden" name="CONTINUE" value="1" >
		<input type="hidden" name="ACTION" value="SEND2BP" >
		<center >
		<br><br><br><br><br>
		<table dir="rtl" width="80%" bgcolor="#e3e3e3" cellpadding="0" cellspacing="1"><tr><td>
		<table class="EPAY" dir="rtl"  width="100%" cellpadding="1" cellspacing="1" bgcolor="white">
			<tr><td colspan="2" class="EPAY_TITLE" height="20"></td></tr>
			<tr height=1 bgcolor="#cecece" ><td colspan="2"></td></tr>
			<tr height=10 ><td colspan="2"></td></tr>
			<tr height="10"><td colspan="2"></td></tr>
			<tr><td colspan="2" dir="rtl" align="center">انتقال مبلغ <b>'.$RIALS.'</b> ريال از حساب شما به حساب <b>'.$epay_plans['fld1'].'</b></td></tr>
			<tr height=20 ><td colspan="2"></td></tr>
			<tr height=1 class="EPAY_LINE" ><td colspan="2"></td></tr>
			<tr><td colspan="2" align="center" bgcolor="#fffffa">
				<input class="EPAY_SUBMIT" type="button" value="بازگشت" onclick="history.go(-1)" >
				<input class="EPAY_SUBMIT" type="submit" value="ادامه">
			</td></tr>
			<tr height=1 class="EPAY_LINE" ><td colspan="2"></td></tr>
			<tr height=10 ><td colspan="2"></td></tr>
		</table>
		</td></tr></table>
		</center>
		</form>
		';
		return true;
	}
}

##-----------------------------------------------------------------------------____________________BRING_NEW_SaleCode
function BRING_NEW_SaleCode(){
	db_connect();
	
	if(!mysql_query(" delete from `epay` where `method`='zarinpal' and `active`=0 and (`pay_date`=0 or `pay_date`<".(U() - 3600*24).") ")){
		echo mysql_error();
	} else if(!$sql=mysql_query(" insert into epay (method,pay_value,pay_date,pay_from,batch_number,active) values ('zarinpal','0','".U()."','".$_SESSION['USER']."','NuN','0') ")){
		ERROR("Error in mysql query:".__LINE__);
		return false;
	} else {
		return mysql_insert_id();
	}
}

function PAY_TO_USER($OrderID=null, $saleReferenceId=null ){
	if(!$OrderID){
		echo "EpMeEu".__LINE__;
		return false;
	} else if(!$saleReferenceId){
		echo "EpMeEu".__LINE__;
		return false;
	} else if(!db_connect()){
		echo "EpMeEu".__LINE__;
		return false;
	} else if(!$sql=mysql_query(" select * from `epay` where 1 and `method`='zarinpal' and `batch_number`='$saleReferenceId' limit 1 ")){
		echo "EpMeEu".__LINE__;
		return false;
	} else if(mysql_num_rows($sql)==1){
		echo "EpMeEu".__LINE__;
		return false;
	} else if(!mysql_query(" update `epay` set `batch_number`='$saleReferenceId' , `active`='1' , `pay_date`='".U()."'  where 1 and `method`='zarinpal' and `id`='$OrderID' limit 1 ")){
		echo "EpMeEu".__LINE__;
		return false;
	} else {
		return true;
	}
}

##-----------------------------------------------------------------------------____________________settle_done
function settle_done($saleReferenceId=null ){
	
	if(!$saleReferenceId){
		echo "EpMeEu".__LINE__;
		die();		
	} else if(!db_connect()){
		echo "EpMeEu".__LINE__;
		die();
	} else if(!$sql=mysql_query(" select * from `epay` where 1 and `method`='zarinpal' and `batch_number`='$saleReferenceId' limit 1 ")){
		echo "EpMeEu".__LINE__;
		die();
	} else if(mysql_num_rows($sql)!=1){
		echo "EpMeEu".__LINE__;
		die();
#	} else if(!$pRec=mysql_fetch_array($sql)){
#		echo "EpMeEu".__LINE__;
#		die();
	} else {
		echo "
		<br><br><br><br>
		<center>
		<table width=400 dir=rtl height=80 cellpadding=2 cellspacing=1 bgcolor='#7c931a'><tr><td bgcolor='#f6fff0' style='font-family:tahoma; font-size:12px; color:#738b3b; ' align=center >
		پاسخ بانک : <b>خرید انجام شد</b>
		<br>
		کد تراکنش : $saleReferenceId
		<br><br> 
		<a href='".str_replace("/epay/zarinpal","",_URL)."/user.php?DPT=U6'>بازگشت به محيط کاربري</a>
		</td></tr></table>
		</center>";
		die();
	}
}

?>
